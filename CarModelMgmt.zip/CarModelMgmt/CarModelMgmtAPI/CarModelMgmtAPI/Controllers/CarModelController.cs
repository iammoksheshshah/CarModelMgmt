﻿using CarModelMgmtAPI.Model;
using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

namespace CarModelMgmtAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarModelController : ControllerBase
    {

        private readonly IConfiguration _configuration;

        public CarModelController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private IDbConnection CreateConnection()
        {
            return new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));
        }

        [HttpPost]
        public async Task<IActionResult> CreateCarModel([FromForm] CarModel model)
        {
            try
            {
                // Check if images are present and valid
                if (model.ImagePaths == null || model.ImagePaths.Count == 0)
                {
                    return BadRequest("No images were uploaded.");
                }

                // Save images to a directory
                var imagePaths = new List<string>();
                foreach (var image in model.ImagePaths)
                {
                    if (image.Length > 0 && image.Length <= 5 * 1024 * 1024) // Max size 5MB
                    {
                        //var filePath = Path.Combine("wwwroot/images", Path.GetFileName(image.FileName));
                        //using (var stream = new FileStream(filePath, FileMode.Create))
                        //{
                        //    await image.CopyToAsync(stream);
                        //}
                        imagePaths.Add(image); // Store the path for database
                    }
                }

                // Save car model to database
                string connectionString = _configuration.GetConnectionString("DefaultConnection");
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("InsertCarModel", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Brand", model.Brand);
                    cmd.Parameters.AddWithValue("@Class", model.Class);
                    cmd.Parameters.AddWithValue("@ModelName", model.ModelName);
                    cmd.Parameters.AddWithValue("@ModelCode", model.ModelCode);
                    cmd.Parameters.AddWithValue("@Description", model.Description);
                    cmd.Parameters.AddWithValue("@Features", model.Features);
                    cmd.Parameters.AddWithValue("@Price", model.Price);
                    cmd.Parameters.AddWithValue("@DateOfManufacturing", model.DateOfManufacturing);
                    cmd.Parameters.AddWithValue("@Active", model.Active);
                    cmd.Parameters.AddWithValue("@SortOrder", model.SortOrder);
                    cmd.Parameters.AddWithValue("@ImagePaths", string.Join("#", imagePaths)); // Save image paths

                    connection.Open();
                    await cmd.ExecuteNonQueryAsync();
                }
                return Ok("Car model created successfully!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetCarModels()
        {
            try
            {
                var carModels = new List<CarModel>();
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (var connection = new SqlConnection(connectionString))
                {
                    var cmd = new SqlCommand("GetAllCarModels", connection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    connection.Open();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var imagePathsString = reader.GetString(reader.GetOrdinal("ImagePaths"));
                            var imagePaths = imagePathsString.Split('#').ToList(); // Split comma-separated paths into list

                            var carModel = new CarModel
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Brand = reader.GetString(reader.GetOrdinal("Brand")),
                                Class = reader.GetString(reader.GetOrdinal("Class")),
                                ModelName = reader.GetString(reader.GetOrdinal("ModelName")),
                                ModelCode = reader.GetString(reader.GetOrdinal("ModelCode")),
                                Description = reader.GetString(reader.GetOrdinal("Description")),
                                Features = reader.GetString(reader.GetOrdinal("Features")),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                DateOfManufacturing = reader.GetDateTime(reader.GetOrdinal("DateOfManufacturing")),
                                Active = reader.GetBoolean(reader.GetOrdinal("Active")),
                                SortOrder = reader.GetInt32(reader.GetOrdinal("SortOrder")),
                                ImagePaths = imagePaths
                            };
                            carModels.Add(carModel);
                        }
                    }
                }

                return Ok(carModels);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpGet("GetCommissionReports")]
        public async Task<IActionResult> GetCommissionReports()
        {
            try
            {
                using (var _dbConnection = CreateConnection())
                {


                    var salesSql = @"SELECT Salesman, Brand, Class, NumberOfCarsSold FROM Sales";
                    var salesData = (await _dbConnection.QueryAsync(salesSql))
                        .Select(x => new
                        {
                            Salesman = (string)x.Salesman,
                            Brand = (string)x.Brand,
                            Class = (string)x.Class,
                            NumberOfCarsSold = (int)x.NumberOfCarsSold
                        });


                    var previousYearSalesSql = @"SELECT Salesman, LastYearTotalSaleAmount FROM PreviousYearSales";
                    var previousYearSalesData = (await _dbConnection.QueryAsync(previousYearSalesSql))
                        .ToDictionary(
                            x => (string)x.Salesman,
                            x => (double)x.LastYearTotalSaleAmount
                        );

                    var brands = new Dictionary<string, (double FixedCommission, double ClassA, double ClassB, double ClassC, double MinAmount)>
                    {
                        { "AUDI", (800, 0.08, 0.06, 0.04, 25000) },
                        { "JAGUAR", (750, 0.06, 0.05, 0.03, 35000) },
                        { "LAND ROVER", (850, 0.07, 0.05, 0.04, 30000) },
                        { "RENAULT", (400, 0.05, 0.03, 0.02, 20000) }
                    };



                    var commissions = new List<CommissionReport>();

                    foreach (var salesmanGroup in salesData.GroupBy(x => x.Salesman))
                    {
                        var salesman = salesmanGroup.Key;
                        double totalCommission = 0;
                        double classACareSellAmount = 0;

                        foreach (var sale in salesmanGroup)
                        {
                            var brand = sale.Brand;
                            var carClass = sale.Class;
                            int numberOfCars = sale.NumberOfCarsSold;

                            string sql = @"SELECT TOP 1 Price FROM CarModels WHERE Brand = @Brand AND Class = @Class ORDER BY Id";
                            double? carPrice = await _dbConnection.QueryFirstOrDefaultAsync<double?>(sql, new { Brand = brand, Class = carClass });
                            double sellAmount = (numberOfCars * (carPrice ?? 0));
                            if (carClass == "A-Class")
                                classACareSellAmount += sellAmount;

                            if (brands.TryGetValue(brand.ToUpper(), out var commissionRates))
                            {
                                if (carPrice != null && carPrice > commissionRates.MinAmount)
                                {
                                    double fixedCommission = commissionRates.FixedCommission;
                                    double classCommission = carClass switch
                                    {
                                        "A-Class" => commissionRates.ClassA,
                                        "B-Class" => commissionRates.ClassB,
                                        "C-Class" => commissionRates.ClassC,
                                        _ => 0
                                    };
                                    double totalBrandCommission = Convert.ToDouble(numberOfCars * (fixedCommission + carPrice * classCommission));
                                    totalCommission += totalBrandCommission;
                                }
                            }
                        }
                        if (previousYearSalesData.TryGetValue(salesman, out double previousYearSales) && previousYearSales > 500000)
                        {
                            totalCommission += classACareSellAmount * 0.02;
                        }
                        commissions.Add(new CommissionReport
                        {
                            Salesman = salesman,
                            TotalCommission = totalCommission
                        });
                    }

                    return Ok(commissions);
                }
            }
            catch (Exception ex)
            {
                // Log the exception (if you have a logging mechanism)
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

    }
}
