using CarModelMgmtAPI.Model;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder => builder.WithOrigins("http://localhost:4200") // Replace with your Angular app URL
                          .AllowAnyHeader()
                          .AllowAnyMethod());
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowSpecificOrigin"); // Use the CORS policy

app.UseAuthorization();

//app.UseMiddleware<ErrorHandlerMiddleware>();

// Centralized API Error Handling
app.Use(async (context, next) =>
{
    try
    {
        context.Response.StatusCode = StatusCodes.Status200OK;
        await next();
    }
    catch (Exception ex)
    {
        // Log exception
        // Handle error
        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        await context.Response.WriteAsync("Internal server error: " + ex.Message);
    }
});

//// Ensure the wwwroot folder exists for serving static files
//if (!Directory.Exists(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot")))
//{
//    Directory.CreateDirectory(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"));
//}

app.MapControllers();

app.Run();
