﻿namespace CarModelMgmtAPI.Model
{
    public class CommissionReport
    {
        public string Salesman { get; set; }
        public double TotalCommission { get; set; }
    }
}
