import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://localhost:7268/api/'; // Replace with your API URL
  private tokenKey = 'authToken';

  constructor(private http: HttpClient, private router: Router) {
    localStorage.setItem(this.tokenKey, "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c");
  }

  // Check if the user is authenticated
  isAuthenticated(): boolean {
    const token = localStorage.getItem(this.tokenKey);
    return !!token; // Returns true if token exists, false otherwise
  }

  // Login method
  login(username: string, password: string): Observable<boolean> {
    return this.http.post<any>(`${this.apiUrl}/login`, { username, password }).pipe(
      map(response => {
        if (response && response.token) {
          localStorage.setItem(this.tokenKey, response.token);
          return true;
        }
        return false;
      }),
      catchError(() => of(false)) // Return false if there's an error
    );
  }

  // Logout method
  logout(): void {
    localStorage.removeItem(this.tokenKey);
    this.router.navigate(['carlist']);
  }

  // Get the current user's token
  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }
}
