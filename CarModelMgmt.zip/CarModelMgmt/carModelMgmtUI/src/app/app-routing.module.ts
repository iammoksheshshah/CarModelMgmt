import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard'; // Import your guards
import { CarModelListComponent } from './car-model/car-model-list/car-model-list.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./car-model/car-model.module').then(m => m.CarModelModule),
    canActivate: [AuthGuard]
  },
  { path: '', redirectTo: '', pathMatch: 'full' }, // Redirect to car-model by default
  { path: '**', redirectTo: '' } // Wildcard route to redirect to car-model
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
