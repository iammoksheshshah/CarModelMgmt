import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarModelService {

  private baseUrl = 'https://localhost:7268/api';

  constructor(private http: HttpClient) { }

  createCarModel(formData: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/CarModel`, formData);
  }

  getCarModels(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/CarModel`);
  }

  getSalesCommisionReport(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/CarModel/GetCommissionReports`);
  }
}
