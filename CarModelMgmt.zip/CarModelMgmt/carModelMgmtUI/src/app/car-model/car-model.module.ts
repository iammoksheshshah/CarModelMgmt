import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CarModelListComponent } from './car-model-list/car-model-list.component';
import { CarModelFormComponent } from './car-model-form/car-model-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { OrderByPipe } from '../pipes/order-by.pipe';
import { SalesCommisionReportComponent } from './sales-commision-report/sales-commision-report.component';

const routes: Routes = [
  {
    path:'',
    pathMatch:'full',
    redirectTo:'carlist'
  },
  { path: 'carlist', component: CarModelListComponent }, // Default route for the feature module
  { path: 'caradd', component: CarModelFormComponent }, // Route for adding new models
  { path: 'salescommition', component: SalesCommisionReportComponent } // Route for adding new models
];

@NgModule({
  declarations: [
    CarModelListComponent,
    CarModelFormComponent,
    OrderByPipe,
    SalesCommisionReportComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
],
exports:[OrderByPipe]
})
export class CarModelModule { }
