import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CarModelService } from './../car-model.service';
import { NotificationService } from '../../auth/notification.service';
import { Router, RouterModule } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-car-model-form',
  templateUrl: './car-model-form.component.html',
  styleUrls: ['./car-model-form.component.scss']
})
export class CarModelFormComponent implements OnInit {
  carModelForm:any= FormGroup;
  selectedFiles:any = [];
  allImages: any;
  isUpload: boolean=false;
  @ViewChild('casrModelNgForm') casrModelNgForm: any;

  constructor(
    private fb: FormBuilder,
    private carModelService: CarModelService,
    private notificationService: NotificationService,
    private router:Router
  ) { }

  ngOnInit(): void {
    this.carModelForm = this.fb.group({
      brand: ['', Validators.required],
      class: ['', Validators.required],
      modelName: ['', Validators.required],
      modelCode: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9]{10}$')]],
      description: ['', Validators.required],
      features: ['', Validators.required],
      price: ['', [Validators.required, Validators.min(0)]],
      dateOfManufacturing: ['', Validators.required],
      active: [true],
      sortOrder: ['', Validators.required]
    });
  }

  // onFileSelected(event: any) {
  //   this.selectedFiles = Array.from(event.target.files);
  // }

  onFileSelected(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      if (event.target.files.length <= 5) {
        if ((event.target.files.length + this.selectedFiles.length) > 5) {
          // this._toastr.clear();
          // this._toastr.error('Please upload maximum 5 images', 'Error');
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: 'Please upload maximum 5 images',
          });
          return;
        }
        let count = 0;
        for (let i = 0; i < event.target.files.length; i++) {
          this.allImages = event.target.files;
          const file = event.target.files[i];
          let type = file.type.split('/')[0];
        if (type == "video") {
            count++;
          }
          if (count > 0) {
           
            Swal.fire({
              icon: "error",
              title: "Oops...",
              text: 'File type is not allowed.',
            });
            count = 0;
            return;
          }
          var reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = (event) => { // called once readAsDataURL is completed
            this.isUpload = true;
            // this.selectedItemImg = event?.target?.result;
            this.selectedFiles.push(event?.target?.result);
            Swal.fire({
              position: "center",
              icon: "success",
              title: 'Image uploaded successfully.',
              showConfirmButton: false,
              timer: 2000,
              width: '400px'
            });
          }
        }
      } else {
        // this._toastr.clear();
        // this._toastr.error('Please upload maximum 5 images', 'Error');
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: 'Please upload maximum 5 images',
        });
      }
    }
  }

  removeOtherImnages(index: any) {
    this.selectedFiles.splice(index, 1)
  }

  onSubmit() {
    if (this.carModelForm.valid) {
      const formData = new FormData();

      // Append form fields to FormData
      formData.append('Brand', this.carModelForm.get('brand').value);
      formData.append('Class', this.carModelForm.get('class').value);
      formData.append('ModelName', this.carModelForm.get('modelName').value);
      formData.append('ModelCode', this.carModelForm.get('modelCode').value);
      formData.append('Description', this.carModelForm.get('description').value);
      formData.append('Features', this.carModelForm.get('features').value);
      formData.append('Price', this.carModelForm.get('price').value);
      formData.append('DateOfManufacturing', this.carModelForm.get('dateOfManufacturing').value);
      formData.append('Active', this.carModelForm.get('active').value.toString());
      formData.append('SortOrder', this.carModelForm.get('sortOrder').value.toString());

      // Append files to FormData
      if (this.selectedFiles) {
          for (let file of this.selectedFiles) {
              // formData.append('images', file); // Make sure 'images' matches the backend parameter name
              formData.append('ImagePaths', file); // Make sure 'images' matches the backend parameter name

          }
      }

      this.carModelService.createCarModel(formData).subscribe(
          (response) => {
              this.notificationService.showSuccess('Car model created successfully!');
              this.carModelForm.reset();
              this.router.navigate(['carlist']);
          },
          (error: any) => {
            if (error.status!=200) {
              this.notificationService.showError(error+'Error creating car model');
              this.carModelForm.reset();
              return;
            }else{
              this.notificationService.showSuccess('Car model created successfully!');
              this.carModelForm.reset();
              this.router.navigate(['carlist']);
            }
          }
      );
    }else{
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: 'Please Enter valid data.',
      });
    }
  }
}
