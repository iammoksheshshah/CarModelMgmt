import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesCommisionReportComponent } from './sales-commision-report.component';

describe('SalesCommisionReportComponent', () => {
  let component: SalesCommisionReportComponent;
  let fixture: ComponentFixture<SalesCommisionReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SalesCommisionReportComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SalesCommisionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
