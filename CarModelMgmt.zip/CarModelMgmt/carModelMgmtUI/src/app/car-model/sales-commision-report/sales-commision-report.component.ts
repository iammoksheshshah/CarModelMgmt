import { Component, OnInit } from '@angular/core';
import { CarModelService } from '../car-model.service';
import { NotificationService } from '../../auth/notification.service';

@Component({
  selector: 'app-sales-commision-report',
  templateUrl: './sales-commision-report.component.html',
  styleUrl: './sales-commision-report.component.scss'
})
export class SalesCommisionReportComponent implements OnInit {
  salesReportData: any[] = [];
  searchTerm: string = '';
  isDataAvail:boolean = false;
  filteredModelsData:any = [];

  constructor(private carModelService: CarModelService,
    private notificationService: NotificationService,
  ) { }

  ngOnInit(): void {
    this.loadCarModels();
  }

  loadCarModels(): void {
    this.carModelService.getSalesCommisionReport().subscribe(data => {
      this.salesReportData = data;
      this.filteredModelsData=this.salesReportData;
      this.isDataAvail = true;
      if (this.salesReportData.length == 0) {
        this.isDataAvail = false;
      }
    },(error:any)=>{
      this.notificationService.showError('Something went wrong...!');
      this.isDataAvail = false;
    });
  }

filteredModels() {
    this.filteredModelsData = this.salesReportData.filter(model => 
      model.salesman.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  searchdata(){
    this.filteredModels();
  }
}
