import { Component, OnInit } from '@angular/core';
import { CarModelService } from '../car-model.service';
import { NotificationService } from '../../auth/notification.service';

@Component({
  selector: 'app-car-model-list',
  templateUrl: './car-model-list.component.html',
  styleUrls: ['./car-model-list.component.scss']
})
export class CarModelListComponent implements OnInit {
  carModels: any[] = [];
  searchTerm: string = '';
  isDataAvail:boolean = false;
  filteredModelsData:any = [];

  constructor(private carModelService: CarModelService,
    private notificationService: NotificationService,
  ) { }

  ngOnInit(): void {
    this.loadCarModels();
  }

  loadCarModels(): void {
    this.carModelService.getCarModels().subscribe(data => {
      this.carModels = data;
      this.filteredModelsData=this.carModels;
      this.isDataAvail = true;
      if (this.carModels.length == 0) {
        this.isDataAvail = false;
      }
    },(error:any)=>{
      this.notificationService.showError('Something went wrong...!');
      this.isDataAvail = false;
    });
  }

filteredModels() {
  this.filteredModelsData = this.carModels.filter(model => 
    model.modelName.toLowerCase().includes(this.searchTerm.toLowerCase()) || 
    model.modelCode.toLowerCase().includes(this.searchTerm.toLowerCase())
  );
  
  }

  searchdata(){
    this.filteredModels();
  }
}
